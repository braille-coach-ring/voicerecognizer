"""
日本語ひらがな全音体系のラベル定義モジュール (config_labels.py)

Issue #20: ラベル体系の拡大（50音 ＋ 濁音 ＋ 半濁音 ＋ 拗音 ＋ その他の全日本語ひらがな対応）
・清音 (46)
・濁音 (20)
・半濁音 (5)
・拗音 (33)
・その他 (1)
計 105 ラベル
"""

from __future__ import annotations

import unicodedata
from typing import Literal

LabelFormat = Literal["raw", "hiragana", "katakana", "romaji"]

# 1. 清音 (Seion: 46 labels)
SEION_LABELS: tuple[str, ...] = (
    "a",
    "i",
    "u",
    "e",
    "o",
    "ka",
    "ki",
    "ku",
    "ke",
    "ko",
    "sa",
    "shi",
    "su",
    "se",
    "so",
    "ta",
    "chi",
    "tsu",
    "te",
    "to",
    "na",
    "ni",
    "nu",
    "ne",
    "no",
    "ha",
    "hi",
    "fu",
    "he",
    "ho",
    "ma",
    "mi",
    "mu",
    "me",
    "mo",
    "ya",
    "yu",
    "yo",
    "ra",
    "ri",
    "ru",
    "re",
    "ro",
    "wa",
    "wo",
    "n",
)

# 2. 濁音 (Dakuon: 20 labels)
DAKUON_LABELS: tuple[str, ...] = (
    "ga",
    "gi",
    "gu",
    "ge",
    "go",
    "za",
    "ji",
    "zu",
    "ze",
    "zo",
    "da",
    "di",
    "du",
    "de",
    "do",
    "ba",
    "bi",
    "bu",
    "be",
    "bo",
)

# 3. 半濁音 (Handakuon: 5 labels)
HANDAKUON_LABELS: tuple[str, ...] = (
    "pa",
    "pi",
    "pu",
    "pe",
    "po",
)

# 4. 拗音 (Yoon: 33 labels)
YOON_LABELS: tuple[str, ...] = (
    "kya",
    "kyu",
    "kyo",
    "sha",
    "shu",
    "sho",
    "cha",
    "chu",
    "cho",
    "nya",
    "nyu",
    "nyo",
    "hya",
    "hyu",
    "hyo",
    "mya",
    "myu",
    "myo",
    "rya",
    "ryu",
    "ryo",
    "gya",
    "gyu",
    "gyo",
    "ja",
    "ju",
    "jo",
    "bya",
    "byu",
    "byo",
    "pya",
    "pyu",
    "pyo",
)

# 5. その他 (Other: 1 label)
OTHER_LABELS: tuple[str, ...] = ("other",)

# 全ラベル統合法則 (105 labels)
ALL_HIRAGANA_LABELS: tuple[str, ...] = (
    SEION_LABELS + DAKUON_LABELS + HANDAKUON_LABELS + YOON_LABELS + OTHER_LABELS
)

# ひらがな ➔ ローマ字（標準一意識別子）
HIRAGANA_TO_ROMAJI: dict[str, str] = {
    # 清音
    "あ": "a",
    "い": "i",
    "う": "u",
    "え": "e",
    "お": "o",
    "か": "ka",
    "き": "ki",
    "く": "ku",
    "け": "ke",
    "こ": "ko",
    "さ": "sa",
    "し": "shi",
    "す": "su",
    "せ": "se",
    "そ": "so",
    "た": "ta",
    "ち": "chi",
    "つ": "tsu",
    "て": "te",
    "と": "to",
    "な": "na",
    "に": "ni",
    "ぬ": "nu",
    "ね": "ne",
    "の": "no",
    "は": "ha",
    "ひ": "hi",
    "ふ": "fu",
    "へ": "he",
    "ほ": "ho",
    "ま": "ma",
    "み": "mi",
    "む": "mu",
    "め": "me",
    "も": "mo",
    "や": "ya",
    "ゆ": "yu",
    "よ": "yo",
    "ら": "ra",
    "り": "ri",
    "る": "ru",
    "れ": "re",
    "ろ": "ro",
    "わ": "wa",
    "を": "wo",
    "ん": "n",
    # 濁音
    "が": "ga",
    "ぎ": "gi",
    "ぐ": "gu",
    "げ": "ge",
    "ご": "go",
    "ざ": "za",
    "じ": "ji",
    "ず": "zu",
    "ぜ": "ze",
    "ぞ": "zo",
    "だ": "da",
    "ぢ": "di",
    "づ": "du",
    "で": "de",
    "ど": "do",
    "ば": "ba",
    "び": "bi",
    "ぶ": "bu",
    "べ": "be",
    "ぼ": "bo",
    # 半濁音
    "ぱ": "pa",
    "ぴ": "pi",
    "ぷ": "pu",
    "ぺ": "pe",
    "ぽ": "po",
    # 拗音
    "きゃ": "kya",
    "きゅ": "kyu",
    "きょ": "kyo",
    "しゃ": "sha",
    "しゅ": "shu",
    "しょ": "sho",
    "ちゃ": "cha",
    "ちゅ": "chu",
    "ちょ": "cho",
    "にゃ": "nya",
    "にゅ": "nyu",
    "にょ": "nyo",
    "ひゃ": "hya",
    "ひゅ": "hyu",
    "ひょ": "hyo",
    "みゃ": "mya",
    "みゅ": "myu",
    "みょ": "myo",
    "りゃ": "rya",
    "りゅ": "ryu",
    "りょ": "ryo",
    "ぎゃ": "gya",
    "ぎゅ": "gyu",
    "ぎょ": "gyo",
    "じゃ": "ja",
    "じゅ": "ju",
    "じょ": "jo",
    "びゃ": "bya",
    "びゅ": "byu",
    "びょ": "byo",
    "ぴゃ": "pya",
    "ぴゅ": "pyu",
    "ぴょ": "pyo",
    # その他
    "other": "other",
    "その他": "other",
}

# ローマ字（標準一意識別子および主要エイリアス） ➔ ひらがな
ROMAJI_TO_HIRAGANA: dict[str, str] = {
    # 清音
    "a": "あ",
    "i": "い",
    "u": "う",
    "e": "え",
    "o": "お",
    "ka": "か",
    "ki": "き",
    "ku": "く",
    "ke": "け",
    "ko": "こ",
    "sa": "さ",
    "shi": "し",
    "su": "す",
    "se": "せ",
    "so": "そ",
    "ta": "た",
    "chi": "ち",
    "tsu": "つ",
    "te": "て",
    "to": "と",
    "na": "な",
    "ni": "に",
    "nu": "ぬ",
    "ne": "ね",
    "no": "の",
    "ha": "は",
    "hi": "ひ",
    "fu": "ふ",
    "he": "へ",
    "ho": "ほ",
    "ma": "ま",
    "mi": "み",
    "mu": "む",
    "me": "め",
    "mo": "も",
    "ya": "や",
    "yu": "ゆ",
    "yo": "よ",
    "ra": "ら",
    "ri": "り",
    "ru": "る",
    "re": "れ",
    "ro": "ろ",
    "wa": "わ",
    "wo": "を",
    "n": "ん",
    # 濁音
    "ga": "が",
    "gi": "ぎ",
    "gu": "ぐ",
    "ge": "げ",
    "go": "ご",
    "za": "ざ",
    "ji": "じ",
    "zu": "ず",
    "ze": "ぜ",
    "zo": "ぞ",
    "da": "だ",
    "di": "ぢ",
    "du": "づ",
    "de": "で",
    "do": "ど",
    "ba": "ば",
    "bi": "び",
    "bu": "ぶ",
    "be": "べ",
    "bo": "ぼ",
    # 半濁音
    "pa": "ぱ",
    "pi": "ぴ",
    "pu": "ぷ",
    "pe": "ぺ",
    "po": "ぽ",
    # 拗音
    "kya": "きゃ",
    "kyu": "きゅ",
    "kyo": "きょ",
    "sha": "しゃ",
    "shu": "しゅ",
    "sho": "しょ",
    "cha": "ちゃ",
    "chu": "ちゅ",
    "cho": "ちょ",
    "nya": "にゃ",
    "nyu": "にゅ",
    "nyo": "にょ",
    "hya": "ひゃ",
    "hyu": "ひゅ",
    "hyo": "ひょ",
    "mya": "みゃ",
    "myu": "みゅ",
    "myo": "みょ",
    "rya": "りゃ",
    "ryu": "りゅ",
    "ryo": "りょ",
    "gya": "ぎゃ",
    "gyu": "ぎゅ",
    "gyo": "ぎょ",
    "ja": "じゃ",
    "ju": "じゅ",
    "jo": "じょ",
    "bya": "びゃ",
    "byu": "びゅ",
    "byo": "びょ",
    "pya": "ぴゃ",
    "pyu": "ぴゅ",
    "pyo": "ぴょ",
    # その他
    "other": "other",
    # 日本語ヘボン式・訓令式エイリアス
    "si": "し",
    "zi": "じ",
    "ti": "ち",
    "tu": "つ",
    "hu": "ふ",
    "sya": "しゃ",
    "syu": "しゅ",
    "syo": "しょ",
    "cya": "ちゃ",
    "cyu": "ちゅ",
    "cyo": "ちょ",
    "tya": "ちゃ",
    "tyu": "ちゅ",
    "tyo": "ちょ",
    "zya": "じゃ",
    "zyu": "じゅ",
    "zyo": "じょ",
    "jya": "じゃ",
    "jyu": "じゅ",
    "jyo": "じょ",
    "nn": "ん",
}


def to_hiragana(text: str | None) -> str:
    """文字列をひらがなに変換・正規化する。

    ローマ字（例: 'ka' -> 'か', 'sha' -> 'しゃ'）や
    カタカナ（例: 'カ' -> 'か', 'キャ' -> 'きゃ'）をひらがなに変換します。
    """
    if text is None:
        return ""
    normalized = unicodedata.normalize("NFKC", str(text)).strip().lower()
    if not normalized:
        return ""

    if normalized in ROMAJI_TO_HIRAGANA:
        return ROMAJI_TO_HIRAGANA[normalized]

    # カタカナ -> ひらがな
    chars: list[str] = []
    for c in normalized:
        code = ord(c)
        if 0x30A1 <= code <= 0x30F6:  # ァ 〜 ヶ
            chars.append(chr(code - 0x60))
        else:
            chars.append(c)
    result = "".join(chars)

    if result in ROMAJI_TO_HIRAGANA:
        return ROMAJI_TO_HIRAGANA[result]

    return result


def to_katakana(text: str | None) -> str:
    """文字列をカタカナに変換・正規化する。

    ローマ字やひらがなをカタカナに変換します。
    """
    hiragana = to_hiragana(text)
    if not hiragana:
        return ""
    if hiragana == "other":
        return "other"
    chars: list[str] = []
    for c in hiragana:
        code = ord(c)
        if 0x3041 <= code <= 0x3096:  # ぁ 〜 ゖ
            chars.append(chr(code + 0x60))
        else:
            chars.append(c)
    return "".join(chars)


def to_romaji(text: str | None) -> str:
    """文字列を標準ローマ字（ヘボン式/プロジェクト標準識別子）に変換・正規化する。

    ひらがなやカタカナ（例: 'か'/'カ' -> 'ka', 'しゃ'/'シャ' -> 'sha'）をローマ字に変換します。
    """
    if text is None:
        return ""
    hiragana = to_hiragana(text)
    if not hiragana:
        return ""
    if hiragana in HIRAGANA_TO_ROMAJI:
        return HIRAGANA_TO_ROMAJI[hiragana]
    return hiragana


def format_label(label: str, target_format: LabelFormat = "hiragana") -> str:
    """指定されたフォーマット（hiragana, katakana, romaji, raw）にラベルを変換する。"""
    if target_format == "hiragana":
        return to_hiragana(label)
    if target_format == "katakana":
        return to_katakana(label)
    if target_format == "romaji":
        return to_romaji(label)
    if target_format == "raw":
        return label
    raise ValueError(
        f"未知の target_format です: {target_format} (有効値: 'raw', 'hiragana', 'katakana', 'romaji')"
    )


